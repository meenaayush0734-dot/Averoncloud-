AveronCloud website
====================

Files
- index.html: complete responsive website. No build tools or dependencies required.

Preview locally
- Open index.html in a browser.

Put it online with your domain
Option A — cPanel/shared hosting:
1. Open your hosting provider's cPanel and go to File Manager.
2. Open public_html (or the document root for your domain).
3. Upload index.html there.
4. Visit your domain and enable SSL/HTTPS in your hosting panel.

Option B — VPS with Nginx:
1. Upload index.html to /var/www/averoncloud/index.html.
2. Configure an Nginx server block for your domain with root /var/www/averoncloud and index index.html.
3. Point your domain's DNS A record to your VPS public IPv4 address (and AAAA only if IPv6 is configured).
4. Enable HTTPS with your host's certificate tool or Certbot.

DNS basics:
- At your domain registrar, find DNS Management.
- Add/modify an A record: Host/Name @, Value = your web server's public IPv4.
- Add/modify www as a CNAME to @ (or an A record to the same IPv4).
- DNS changes can take time to propagate.

Customize before launch:
- The Discord invite is already set to https://discord.gg/eEarqCfyg.
- Prices and exact hardware specs are intentionally shown as “Custom” because none were supplied. Edit the text in index.html once you have confirmed plan prices, RAM, CPU, storage, and locations.
- The website says “Make a ticket for buy” and every Buy button opens your Discord invite.
